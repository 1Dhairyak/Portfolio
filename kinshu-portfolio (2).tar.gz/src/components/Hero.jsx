import { motion } from "framer-motion";
import { FaLinkedin, FaGithub, FaInstagram } from "react-icons/fa";
import profileImg from "../assets/profile.jpg";

export default function Hero() {
  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center z-10 px-8"
    >
      <div className="max-w-6xl w-full mx-auto flex flex-col md:flex-row items-center gap-16">
        {/* Terminal frame photo */}
        <motion.div
          initial={{ x: -60, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="flex-shrink-0"
        >
          <div className="bg-[#1c1c1c] rounded-xl overflow-hidden border border-white/10 shadow-2xl w-72">
            {/* Terminal title bar */}
            <div className="flex items-center gap-2 px-4 py-2.5 bg-[#2a2a2a] border-b border-white/5">
              <span className="w-3 h-3 rounded-full bg-red-500" />
              <span className="w-3 h-3 rounded-full bg-yellow-400" />
              <span className="w-3 h-3 rounded-full bg-green-400" />
              <span className="ml-2 text-xs text-white/40 font-mono">
                Profile.jpg — Dhairya Kumar
              </span>
            </div>
            <img
              src={profileImg}
              alt="Dhairya Kumar"
              className="w-full object-cover"
              style={{ maxHeight: "320px" }}
            />
            <div className="px-4 py-3 font-mono text-sm text-accent">
              <span className="text-white/40">$ </span>
              ./Profile.jpg Loaded Successfully
              <span className="animate-pulse">|</span>
            </div>
          </div>
        </motion.div>

        {/* Text content */}
        <motion.div
          initial={{ x: 60, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-center md:text-left"
        >
          <p className="font-mono text-accent text-sm mb-3 tracking-widest uppercase">
            Console.Log("Hello World")
          </p>
          <h1 className="font-sans font-extrabold text-5xl md:text-6xl text-white mb-3 leading-tight">
            I Am{" "}
            <span className="text-accent">Dhairya Kumar</span>
          </h1>
          <p className="text-white/60 text-lg font-sans mb-8">
            Cloud & Backend Engineer / Full Stack Developer
          </p>

          <div className="flex gap-4 justify-center md:justify-start mb-8">
            {[
              { icon: <FaLinkedin size={22} />, href: "https://linkedin.com/in/1dhairyak", label: "LinkedIn" },
              { icon: <FaGithub size={22} />, href: "https://github.com/1Dhairyak", label: "GitHub" },
              { icon: <FaInstagram size={22} />, href: "https://instagram.com/dhairya_k", label: "Instagram" },
            ].map(({ icon, href, label }) => (
              <a
                key={label}
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                className="w-12 h-12 rounded-full border-2 border-accent text-accent flex items-center justify-center hover:bg-accent hover:text-black transition-all duration-300"
              >
                {icon}
              </a>
            ))}
          </div>

          <a
            href="#projects"
            onClick={(e) => {
              e.preventDefault();
              document.getElementById("projects")?.scrollIntoView({ behavior: "smooth" });
            }}
            className="inline-flex items-center gap-2 bg-accent text-black font-bold px-7 py-3 rounded-full hover:bg-accent/80 transition-colors duration-300 font-mono text-sm"
          >
            View Projects →
          </a>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        animate={{ y: [0, 8, 0] }}
        transition={{ repeat: Infinity, duration: 1.5 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 text-accent/50 text-2xl"
      >
        ↓
      </motion.div>
    </section>
  );
}
