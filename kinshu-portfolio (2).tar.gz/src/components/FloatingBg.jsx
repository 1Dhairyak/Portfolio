import { useEffect, useRef } from "react";

const snippets = [
  "@RestController", "@Service", "@Entity", "JpaRepository",
  "docker-compose up", "spring.jpa.ddl-auto", "@GetMapping",
  "@PostMapping", "JWT.verify()", "RedisTemplate",
  "@SpringBootTest", "ResponseEntity<>", "Optional.of()",
  "SELECT * FROM", "CREATE TABLE", "@Column", "@ManyToOne",
  "useEffect(() => {", "useState()", "fetch('/api')",
  "npm run dev", "git push origin", "mvn clean install",
  "SETEX token", "@Valid", "HttpStatus.OK",
  "@ElementCollection", "Pageable.ofSize(10)",
  "WebSocketSession", "ObjectMapper", "@Autowired",
];

export default function FloatingBg() {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    let animId;
    let W = (canvas.width = window.innerWidth);
    let H = (canvas.height = window.innerHeight);

    const particles = Array.from({ length: 40 }, () => ({
      x: Math.random() * W,
      y: Math.random() * H,
      text: snippets[Math.floor(Math.random() * snippets.length)],
      speed: 0.15 + Math.random() * 0.3,
      alpha: 0.08 + Math.random() * 0.18,
      size: 10 + Math.random() * 6,
      drift: (Math.random() - 0.5) * 0.2,
    }));

    // Dot network
    const dots = Array.from({ length: 80 }, () => ({
      x: Math.random() * W,
      y: Math.random() * H,
      vx: (Math.random() - 0.5) * 0.3,
      vy: (Math.random() - 0.5) * 0.3,
    }));

    function draw() {
      ctx.clearRect(0, 0, W, H);

      // Draw network
      dots.forEach((d) => {
        d.x += d.vx;
        d.y += d.vy;
        if (d.x < 0 || d.x > W) d.vx *= -1;
        if (d.y < 0 || d.y > H) d.vy *= -1;
      });

      for (let i = 0; i < dots.length; i++) {
        for (let j = i + 1; j < dots.length; j++) {
          const dx = dots[i].x - dots[j].x;
          const dy = dots[i].y - dots[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 130) {
            ctx.beginPath();
            ctx.strokeStyle = `rgba(255,255,255,${0.04 * (1 - dist / 130)})`;
            ctx.lineWidth = 0.5;
            ctx.moveTo(dots[i].x, dots[i].y);
            ctx.lineTo(dots[j].x, dots[j].y);
            ctx.stroke();
          }
        }
        ctx.beginPath();
        ctx.arc(dots[i].x, dots[i].y, 1.5, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(255,255,255,0.15)";
        ctx.fill();
      }

      // Draw floating snippets
      particles.forEach((p) => {
        p.y -= p.speed;
        p.x += p.drift;
        if (p.y < -20) {
          p.y = H + 20;
          p.x = Math.random() * W;
          p.text = snippets[Math.floor(Math.random() * snippets.length)];
        }
        ctx.font = `${p.size}px 'JetBrains Mono', monospace`;
        ctx.fillStyle = `rgba(0,255,157,${p.alpha})`;
        ctx.fillText(p.text, p.x, p.y);
      });

      animId = requestAnimationFrame(draw);
    }

    draw();

    const onResize = () => {
      W = canvas.width = window.innerWidth;
      H = canvas.height = window.innerHeight;
    };
    window.addEventListener("resize", onResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("resize", onResize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 w-full h-full pointer-events-none z-0"
    />
  );
}
