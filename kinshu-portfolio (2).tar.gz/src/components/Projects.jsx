import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { projects } from "../data/projects";
import { FaGithub, FaExternalLinkAlt } from "react-icons/fa";

export default function Projects() {
  const [current, setCurrent] = useState(0);

  const prev = () => setCurrent((c) => (c === 0 ? projects.length - 1 : c - 1));
  const next = () => setCurrent((c) => (c === projects.length - 1 ? 0 : c + 1));

  const getIndex = (offset) => (current + offset + projects.length) % projects.length;

  return (
    <section id="projects" className="relative z-10 py-24 px-8">
      <div className="max-w-6xl mx-auto">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center text-4xl font-bold text-white mb-4 font-sans tracking-wide"
        >
          Projects
        </motion.h2>
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="text-center text-white/40 font-mono text-sm mb-16"
        >
          // shipped, deployed, and actually working
        </motion.p>

        {/* Carousel */}
        <div className="relative flex items-center justify-center gap-6 min-h-[420px]">
          {/* Prev ghost card */}
          <div
            className="hidden lg:block w-64 flex-shrink-0 cursor-pointer opacity-40 scale-90 transition-all duration-300 hover:opacity-60"
            onClick={prev}
          >
            <ProjectCard project={projects[getIndex(-1)]} mini />
          </div>

          {/* Main card */}
          <AnimatePresence mode="wait">
            <motion.div
              key={current}
              initial={{ opacity: 0, scale: 0.93, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.93, y: -20 }}
              transition={{ duration: 0.35 }}
              className="w-full max-w-md flex-shrink-0"
            >
              <ProjectCard project={projects[current]} main />
            </motion.div>
          </AnimatePresence>

          {/* Next ghost card */}
          <div
            className="hidden lg:block w-64 flex-shrink-0 cursor-pointer opacity-40 scale-90 transition-all duration-300 hover:opacity-60"
            onClick={next}
          >
            <ProjectCard project={projects[getIndex(1)]} mini />
          </div>

          {/* Arrow buttons */}
          <button
            onClick={prev}
            className="absolute left-0 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full border border-white/20 text-white/60 hover:border-accent hover:text-accent flex items-center justify-center transition-all duration-200 lg:hidden"
          >
            ←
          </button>
          <button
            onClick={next}
            className="absolute right-0 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full border border-white/20 text-white/60 hover:border-accent hover:text-accent flex items-center justify-center transition-all duration-200 lg:hidden"
          >
            →
          </button>
        </div>

        {/* Dot indicators */}
        <div className="flex justify-center gap-2 mt-10">
          {projects.map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrent(i)}
              className={`w-2 h-2 rounded-full transition-all duration-300 ${
                i === current ? "bg-accent w-6" : "bg-white/25 hover:bg-white/50"
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

function ProjectCard({ project, main, mini }) {
  return (
    <div
      className={`rounded-2xl border overflow-hidden transition-all duration-300 ${
        main
          ? "border-accent/30 bg-white/[0.04] shadow-2xl shadow-accent/5"
          : "border-white/10 bg-white/[0.02]"
      }`}
    >
      {/* Project banner */}
      <div
        className="flex items-center justify-center font-mono text-5xl"
        style={{
          background: project.color,
          height: main ? "200px" : "130px",
        }}
      >
        {project.icon}
      </div>

      <div className={`${main ? "p-6" : "p-4"}`}>
        <h3
          className={`text-white font-bold font-sans ${
            main ? "text-2xl mb-2" : "text-base mb-1"
          }`}
        >
          {project.title}
        </h3>

        {main && (
          <p className="text-white/50 text-sm mb-4 leading-relaxed font-sans">
            {project.description}
          </p>
        )}

        {/* Tech tags */}
        <div className="flex flex-wrap gap-1.5 mb-4">
          {project.tags.map((tag) => (
            <span
              key={tag}
              className="text-xs font-mono text-accent/70 border border-accent/20 px-2 py-0.5 rounded"
            >
              {tag}
            </span>
          ))}
        </div>

        {main && (
          <div className="flex gap-3">
            {project.repo && (
              <a
                href={project.repo}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 border border-white/30 text-white px-4 py-2 rounded-full text-sm font-mono hover:border-accent hover:text-accent transition-all duration-200"
              >
                <FaGithub size={14} />
                Repository
              </a>
            )}
            {project.demo && (
              <a
                href={project.demo}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 bg-accent text-black px-4 py-2 rounded-full text-sm font-mono font-bold hover:bg-accent/80 transition-all duration-200"
              >
                <FaExternalLinkAlt size={12} />
                Live Demo
              </a>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
