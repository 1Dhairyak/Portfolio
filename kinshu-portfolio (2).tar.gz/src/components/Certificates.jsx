import { motion } from "framer-motion";
import { certificates } from "../data/certificates";

export default function Certificates() {
  return (
    <section id="certificates" className="relative z-10 py-24 px-8">
      <div className="max-w-6xl mx-auto">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center text-4xl font-bold text-white mb-4 font-sans tracking-wide"
        >
          Certificates
        </motion.h2>
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="text-center text-white/40 font-mono text-sm mb-16"
        >
          // credentials that back the skills
        </motion.p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {certificates.map((cert, i) => (
            <motion.div
              key={cert.name}
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.07, duration: 0.4 }}
              whileHover={{ y: -4, borderColor: "rgba(0,255,157,0.4)" }}
              className="bg-white/[0.03] border border-white/10 rounded-xl p-5 flex items-center gap-4 cursor-default transition-all duration-300"
            >
              <div
                className="w-10 h-10 rounded-lg flex items-center justify-center text-lg flex-shrink-0"
                style={{ background: cert.color + "22", border: `1px solid ${cert.color}44` }}
              >
                🎓
              </div>
              <div>
                <p className="text-white font-semibold text-sm font-sans leading-tight">{cert.name}</p>
                <p className="text-white/40 text-xs font-mono mt-1">
                  {cert.issuer} · {cert.year}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
          className="flex justify-center mt-12"
        >
          <a
            href="https://www.linkedin.com/in/1dhairyak"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 bg-accent text-black font-bold px-8 py-3 rounded-full font-mono text-sm hover:bg-accent/80 transition-all duration-300"
          >
            View All on LinkedIn →
          </a>
        </motion.div>
      </div>
    </section>
  );
}
