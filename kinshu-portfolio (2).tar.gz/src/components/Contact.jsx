import { useState } from "react";
import { motion } from "framer-motion";
import { FaEnvelope, FaLinkedin, FaGithub, FaInstagram } from "react-icons/fa";

const socials = [
  { icon: <FaEnvelope size={22} />, href: "mailto:dhairya@email.com", label: "Email", color: "#EA4335", border: "#EA433566" },
  { icon: <FaInstagram size={22} />, href: "https://instagram.com/dhairya_k", label: "Instagram", color: "#E1306C", border: "#E1306C66" },
  { icon: <FaLinkedin size={22} />, href: "https://linkedin.com/in/1dhairyak", label: "LinkedIn", color: "#0A66C2", border: "#0A66C266" },
  { icon: <FaGithub size={22} />, href: "https://github.com/1Dhairyak", label: "GitHub", color: "#ffffff", border: "#ffffff44" },
];

const platforms = ["Gmail", "LinkedIn", "GitHub", "Instagram"];

export default function Contact() {
  const [platformIdx, setPlatformIdx] = useState(0);

  // Cycle through platforms on hover/click
  const cyclePlatform = () => setPlatformIdx((i) => (i + 1) % platforms.length);

  return (
    <section id="contact" className="relative z-10 py-24 px-8">
      <div className="max-w-6xl mx-auto">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center text-4xl font-bold text-white mb-16 font-sans tracking-wide"
        >
          Contact
        </motion.h2>

        <div className="flex flex-col items-center gap-12">
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-2xl font-sans text-white"
          >
            Contact me by:{" "}
            <span
              className="text-accent font-mono cursor-pointer select-none"
              onClick={cyclePlatform}
              title="Click to cycle"
            >
              {platforms[platformIdx]}
              <span className="animate-pulse">|</span>
            </span>
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
            className="flex gap-6"
          >
            {socials.map(({ icon, href, label, color, border }) => (
              <a
                key={label}
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                title={label}
                className="w-14 h-14 rounded-xl flex items-center justify-center transition-all duration-300 hover:scale-110"
                style={{
                  border: `2px solid ${border}`,
                  color: color,
                  background: color + "11",
                }}
              >
                {icon}
              </a>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
