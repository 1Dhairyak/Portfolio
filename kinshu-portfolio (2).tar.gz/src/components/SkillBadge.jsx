import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function SkillBadge({ skill }) {
  const [hovered, setHovered] = useState(false);
  const [expanded, setExpanded] = useState(false);

  return (
    <div
      className="relative"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => {
        setHovered(false);
        setExpanded(false);
      }}
    >
      <motion.span
        whileHover={{ scale: 1.45 }}
        animate={{ scale: hovered ? 1.45 : 1 }}
        transition={{ type: "spring", stiffness: 320, damping: 18 }}
        style={{ transformOrigin: "center" }}
        className={`relative z-10 flex items-center gap-1.5 bg-white/5 border text-xs px-3 py-1.5 rounded-full font-mono cursor-default transition-colors duration-200 ${
          hovered
            ? "border-accent text-accent shadow-[0_0_18px_rgba(0,255,157,0.35)]"
            : "border-white/10 text-white/70"
        }`}
      >
        <span>{skill.icon}</span>
        {skill.name}
      </motion.span>

      <AnimatePresence>
        {hovered && (
          <motion.div
            initial={{ opacity: 0, y: 8, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 8, scale: 0.95 }}
            transition={{ duration: 0.18 }}
            className="absolute left-1/2 -translate-x-1/2 top-[calc(100%+10px)] w-64 bg-card border border-accent/30 rounded-lg p-3 shadow-2xl z-20 font-sans"
          >
            <p className="text-white/80 text-xs leading-relaxed">
              {expanded ? skill.detail : skill.desc}
            </p>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setExpanded((v) => !v);
              }}
              className="mt-2 text-accent text-[11px] font-mono hover:underline"
            >
              {expanded ? "Show less ←" : "Read more →"}
            </button>
            <div className="absolute -top-1.5 left-1/2 -translate-x-1/2 w-3 h-3 bg-card border-l border-t border-accent/30 rotate-45" />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
