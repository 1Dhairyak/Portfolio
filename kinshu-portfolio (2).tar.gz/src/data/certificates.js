export const certificates = [
  { name: "Google Cloud Fundamentals", issuer: "Google Cloud", year: "2024", color: "#4285F4" },
  { name: "Machine Learning Specialization", issuer: "Coursera", year: "2024", color: "#0056D2" },
  { name: "Deep Learning Specialization", issuer: "Coursera", year: "2024", color: "#0056D2" },
  { name: "Full Stack Web Dev", issuer: "Coursera", year: "2023", color: "#0056D2" },
  { name: "Responsive Web Design", issuer: "Scrimba", year: "2023", color: "#FF6B6B" },
  { name: "Responsible & Safe AI Systems", issuer: "Vanderbilt", year: "2024", color: "#866EB2" },
  { name: "Python for Everybody", issuer: "UC San Diego", year: "2023", color: "#00629B" },
  { name: "Data Structures & Algorithms", issuer: "UC Boulder", year: "2024", color: "#CFB87C" },
  { name: "Cloud Computing Concepts", issuer: "Coursera", year: "2024", color: "#0056D2" },
];
