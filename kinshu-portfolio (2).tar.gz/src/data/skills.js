export const skills = {
  backend: [
    { name: "Java", icon: "☕", desc: "Core language for all backend systems — JRS, GeoScale, BallKnowledge.", detail: "Primary language for backend development. Used across JRS (Spring Boot 3.3, Java 21), GeoScale (Java 17), and BallKnowledge. Comfortable with streams, concurrency, and OOP design patterns in production code." },
    { name: "Spring Boot", icon: "🍃", desc: "REST APIs, microservices, dependency injection.", detail: "Built multiple production-grade REST APIs and microservices. JRS uses Spring Boot 3.3 with a refactored modular architecture (23 files from a 1,760-line monolith). GeoScale uses 3.5 with WebSockets for real-time match handling." },
    { name: "Spring Security", icon: "🔐", desc: "JWT auth, route protection, BCrypt hashing.", detail: "Implemented JWT-based authentication (HS256) in JRS's API Gateway, and BCrypt password hashing + auth flows in GeoScale. Familiar with securing endpoints, role-based access, and avoiding common pitfalls like plaintext secrets in commits." },
    { name: "JPA/Hibernate", icon: "🗄️", desc: "ORM mapping, entity relationships, query tuning.", detail: "Used JPA/Hibernate across JRS and GeoScale for entity modeling and relational mapping. Debugged real production issues like malformed JPQL queries and MapStruct bean-wiring failures tied to entity mapping." },
    { name: "REST APIs", icon: "🔌", desc: "Designed and consumed RESTful endpoints end-to-end.", detail: "Designed REST APIs from scratch for JRS, GeoScale, SearchWars, and BallKnowledge — including pagination, filtering, error handling (RFC 7807), and OpenAPI documentation." },
    { name: "MapStruct", icon: "🗺️", desc: "DTO-entity mapping in Spring Boot.", detail: "Used MapStruct 1.5.5 in JRS for clean DTO-to-entity conversion. Resolved real bean-wiring failures during refactor — a common gotcha when MapStruct interfaces aren't picked up correctly by Spring's component scan." },
  ],
  frontend: [
    { name: "React", icon: "⚛️", desc: "Component-driven UIs across 8 deployed projects.", detail: "Built and shipped React frontends for every major project — JRS (with Three.js integration), GeoScale, SearchWars, BallKnowledge, and this portfolio. Comfortable with hooks, state management, and component architecture." },
    { name: "Vite", icon: "⚡", desc: "Fast dev server and build tooling for all React apps.", detail: "Standard build tool across all frontend projects for fast HMR and optimized production builds. Diagnosed and fixed real-world Vite setup issues — missing node_modules, PATH/script errors on Windows." },
    { name: "Tailwind CSS", icon: "🎨", desc: "Utility-first styling, dark/terminal aesthetic.", detail: "Used for rapid, consistent styling across projects, including this portfolio's dark terminal aesthetic and GeoScale's white/purple UI redesign." },
    { name: "Framer Motion", icon: "🎬", desc: "Scroll animations, hover transitions, micro-interactions.", detail: "Powers the animated, interactive feel of this portfolio — scroll-triggered fade-ins, hover scaling, and smooth transitions throughout." },
    { name: "JavaScript", icon: "🟨", desc: "ES6+, async patterns, DOM manipulation.", detail: "Strong JS fundamentals underpinning all React work, plus standalone scripting — automation scripts, canvas-based animations in this portfolio's floating background." },
    { name: "HTML/CSS", icon: "🌐", desc: "Semantic markup and responsive layout foundations.", detail: "Foundation for every web project — responsive layouts, accessibility basics, and custom CSS where Tailwind utilities aren't enough, like canvas-based effects." },
  ],
  cloud: [
    { name: "AWS", icon: "☁️", desc: "Lake Formation, Iceberg, cost management, ECS Fargate.", detail: "Coursework and hands-on labs in AWS Lake Formation/Iceberg, PySpark star schemas, and an AWS cost management tool project. Deployed JRS's API Gateway config for ECS Fargate." },
    { name: "Azure", icon: "🔷", desc: "Cloud-native architecture coursework and labs.", detail: "Studied Azure cloud-native architecture as part of cloud computing specialization, complementing AWS-focused project work." },
    { name: "Docker", icon: "🐳", desc: "Containerized backend services for deployment.", detail: "Containerized GeoScale's backend and used Docker/docker-compose in FintelIQ's planned infrastructure. Comfortable with multi-stage builds and docker-compose orchestration." },
    { name: "Vercel", icon: "▲", desc: "Frontend deployment for React apps.", detail: "Deployed React frontends for SearchWars, BallKnowledge, and GeoScale to Vercel, including environment variable configuration and CORS setup." },
    { name: "Render", icon: "🚀", desc: "Backend hosting for Spring Boot services.", detail: "Deployed BallKnowledge's Spring Boot backend to Render, handling production config separate from local dev." },
    { name: "CI/CD", icon: "⚙️", desc: "Automated builds, deployment pipelines.", detail: "Set up deployment pipelines for SearchWars (Vercel + Railway) and worked with Testcontainers-based test suites (44 tests) as part of JRS's gateway service." },
  ],
  database: [
    { name: "PostgreSQL", icon: "🐘", desc: "Primary relational DB across most projects.", detail: "Primary database for JRS, GeoScale, SearchWars, and the Higher-Lower backend. Handled schema design, foreign key constraints, and connection config across local (port 5433) and cloud deployments." },
    { name: "Redis", icon: "🔴", desc: "Caching and rate limiting.", detail: "Used Redis for rate limiting in JRS's API Gateway and as a caching layer in planned FintelIQ infrastructure." },
    { name: "MongoDB", icon: "🍃", desc: "NoSQL store for Serenity's wellness backend.", detail: "Used MongoDB with Node.js/Express in Serenity — a wellness platform backend handling mood tracking, journaling, and assessment data." },
    { name: "SQL", icon: "📋", desc: "Query writing, joins, schema design.", detail: "Strong SQL fundamentals from coursework (PySpark star schema labs) and real debugging work, including fixing malformed JPQL queries in production code." },
  ],
};
