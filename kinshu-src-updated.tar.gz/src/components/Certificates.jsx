import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { certificates } from "../data/certificates";

const ALL_CATEGORIES = ["All", ...Array.from(new Set(certificates.map((c) => c.category)))];

export default function Certificates() {
  const [activeCategory, setActiveCategory] = useState("All");
  const [selected, setSelected] = useState(null);

  const filtered =
    activeCategory === "All"
      ? certificates
      : certificates.filter((c) => c.category === activeCategory);

  return (
    <section id="certificates" className="relative z-10 py-24 px-8">
      <div className="max-w-6xl mx-auto">

        {/* Header — terminal code block */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-[#1a1a1a] border border-white/10 rounded-xl overflow-hidden mb-12 shadow-xl"
        >
          <div className="flex items-center gap-2 px-5 py-3 bg-[#222] border-b border-white/5">
            <span className="w-3 h-3 rounded-full bg-red-500" />
            <span className="w-3 h-3 rounded-full bg-yellow-400" />
            <span className="w-3 h-3 rounded-full bg-green-400" />
            <span className="ml-auto text-xs text-white/30 font-mono">Certificates.js — Portfolio</span>
          </div>
          <div className="px-6 py-5 font-mono text-sm leading-7">
            <p><span className="text-purple-400">const</span> <span className="text-accent">Certificates</span> <span className="text-white/50">= {"{"}</span></p>
            <p className="pl-6"><span className="text-blue-300">Total</span><span className="text-white/50">:</span> <span className="text-orange-300">{certificates.length}</span><span className="text-white/50">,</span></p>
            <p className="pl-6"><span className="text-blue-300">Categories</span><span className="text-white/50">:</span> <span className="text-orange-300">[{ALL_CATEGORIES.slice(1).map(c => `"${c}"`).join(", ")}]</span><span className="text-white/50">,</span></p>
            <p className="pl-6"><span className="text-blue-300">Status</span><span className="text-white/50">:</span> <span className="text-green-400">"Verified"</span></p>
            <p><span className="text-white/50">{"}"}</span><span className="text-white/50">;</span></p>
          </div>
        </motion.div>

        {/* Section title */}
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center text-4xl font-bold text-accent font-mono mb-2"
        >
          &lt;My Certificates/&gt;
        </motion.h2>
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.15 }}
          className="text-center text-white/40 font-mono text-sm mb-10"
        >
          $ Cat Achievements.Log
        </motion.p>

        {/* Category filter terminal bar */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="bg-[#1a1a1a] border border-white/10 rounded-xl p-4 mb-10 shadow-lg"
        >
          <div className="flex items-center gap-2 mb-3">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
            <span className="w-2.5 h-2.5 rounded-full bg-yellow-400" />
            <span className="w-2.5 h-2.5 rounded-full bg-green-400" />
            <span className="ml-3 text-white/30 font-mono text-xs">Filter@Certificates:~$</span>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-accent font-mono text-xs mr-1">$ Grep --Category=</span>
            {ALL_CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-4 py-1.5 rounded-md text-xs font-mono transition-all duration-200 border ${
                  activeCategory === cat
                    ? "bg-accent text-black border-accent font-bold"
                    : "border-white/15 text-white/50 hover:border-accent/50 hover:text-white/80"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </motion.div>

        {/* Certificate cards grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          <AnimatePresence mode="popLayout">
            {filtered.map((cert, i) => (
              <motion.div
                key={cert.name}
                layout
                initial={{ opacity: 0, y: 25 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ delay: i * 0.05, duration: 0.35 }}
                className="bg-[#111] border border-white/10 rounded-xl overflow-hidden cursor-pointer group hover:border-accent/40 transition-all duration-300 hover:shadow-[0_0_20px_rgba(0,255,157,0.08)]"
                onClick={() => setSelected(cert)}
              >
                {/* Terminal title bar */}
                <div className="flex items-center gap-2 px-4 py-2.5 bg-[#1a1a1a] border-b border-white/5">
                  <span className="w-2 h-2 rounded-full bg-red-500/70" />
                  <span className="w-2 h-2 rounded-full bg-yellow-400/70" />
                  <span className="w-2 h-2 rounded-full bg-green-400/70" />
                  <span className="ml-auto text-[10px] font-mono text-white/20 truncate max-w-[140px]">
                    {cert.name.replace(/ /g, "_").toLowerCase()}.Cert
                  </span>
                  <span
                    className="text-[10px] font-mono px-1.5 py-0.5 rounded"
                    style={{ color: cert.color, background: cert.color + "22" }}
                  >
                    .{cert.category}
                  </span>
                </div>

                {/* Certificate image preview */}
                <div className="relative h-36 overflow-hidden bg-white/5">
                  {cert.image ? (
                    <img src={cert.image} alt={cert.name} className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <div className="text-center">
                        <div className="text-4xl mb-2">🎓</div>
                        <p className="text-white/20 font-mono text-xs">{cert.issuer}</p>
                      </div>
                    </div>
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#111] via-transparent to-transparent" />
                </div>

                {/* Card body */}
                <div className="p-4">
                  <h3 className="text-accent font-mono text-sm font-semibold leading-snug mb-2 group-hover:text-accent transition-colors">
                    {cert.name}
                  </h3>
                  <p className="text-white/40 font-mono text-xs mb-1">
                    <span className="text-white/25">// Issued By:</span> {cert.issuer}
                  </p>
                  <p className="text-white/40 font-mono text-xs mb-3">
                    <span className="text-white/25">// Year:</span> {cert.year}
                  </p>
                  <div className="flex flex-wrap gap-1.5 mb-3">
                    {cert.skills?.map((s) => (
                      <span key={s} className="text-[10px] font-mono px-2 py-0.5 rounded border border-white/10 text-white/40">
                        {s}
                      </span>
                    ))}
                  </div>
                  <p className="text-accent/60 font-mono text-[11px] group-hover:text-accent transition-colors">
                    $ Cat Certificate.Details
                  </p>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>

      {/* Lightbox Modal */}
      <AnimatePresence>
        {selected && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
            onClick={() => setSelected(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.92, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.92, y: 20 }}
              transition={{ duration: 0.25 }}
              className="bg-[#111] border border-accent/30 rounded-2xl overflow-hidden max-w-2xl w-full shadow-2xl max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Modal title bar */}
              <div className="flex items-center gap-2 px-5 py-3.5 bg-[#1a1a1a] border-b border-white/10 sticky top-0">
                <span className="w-3 h-3 rounded-full bg-red-500" />
                <span className="w-3 h-3 rounded-full bg-yellow-400" />
                <span className="w-3 h-3 rounded-full bg-green-400" />
                <span className="ml-2 text-xs font-mono text-white/40">Certificate_details.Json</span>
                <button
                  onClick={() => setSelected(null)}
                  className="ml-auto text-white/40 hover:text-white transition-colors text-lg leading-none"
                >
                  ✕
                </button>
              </div>

              {/* Certificate image */}
              {selected.image && (
                <div className="bg-white/5 border-b border-white/5">
                  <img src={selected.image} alt={selected.name} className="w-full max-h-72 object-contain object-top" />
                </div>
              )}

              {/* Modal body */}
              <div className="p-6">
                <h3 className="text-accent font-mono text-xl font-bold mb-4">{selected.name}</h3>
                <div className="space-y-2 mb-4">
                  <p className="font-mono text-sm"><span className="text-white/40">Issuer:</span> <span className="text-white/80">{selected.issuer}</span></p>
                  <p className="font-mono text-sm"><span className="text-white/40">Year:</span> <span className="text-white/80">{selected.year}</span></p>
                  <p className="font-mono text-sm"><span className="text-white/40">Category:</span> <span style={{ color: selected.color }}>{selected.category}</span></p>
                </div>

                {selected.verifyUrl && (
                  <a
                    href={selected.verifyUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 font-mono text-xs text-accent border border-accent/30 px-4 py-2 rounded-lg hover:bg-accent/10 transition-colors mb-4"
                  >
                    $ Curl -X GET Verify Certificate
                  </a>
                )}

                {selected.skills && selected.skills.length > 0 && (
                  <div>
                    <p className="font-mono text-xs text-white/30 mb-2">// Skills Covered:</p>
                    <div className="flex flex-wrap gap-2">
                      {selected.skills.map((s) => (
                        <span key={s} className="text-xs font-mono px-3 py-1 rounded border border-white/15 text-white/60">
                          {s}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
